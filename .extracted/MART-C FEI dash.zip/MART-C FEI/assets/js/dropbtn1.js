function myFunction1() {
    var dropdownContent = document.getElementById("myDropdown1");
    if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
    } else {
        dropdownContent.style.display = "block";
    }
  }